const mongoose=require('mongoose')
const dbConfig=require('./config/db.config.js')
const Product=require('./model/product.model.js')

mongoose.connect(dbConfig.url).then(()=>{
    console.log("database connected")
}).catch((err)=>{
     console.log("database not connected due to",err)
})



addproduct=async function(name,cat,price)
{
    var countProd = await Product.find().countDocuments();
        const maxId = countProd + 1;  

const product1=new Product({    
productName:name,
productLine:cat,
productScale:"4:10",
productVendor:"Green Hash Mine",
productDescription:"Model features, official Harley Davidson logos and insignias, detachab…",
quantityInStock:98230,
buyPrice:price,
MSRP:"34.99",
image:"data/"+maxId+".jpg",
productID:maxId
})

await product1.save().then(()=>{
    console.log("Record has been saved with Id: ",maxId);
}).catch((err)=>{
    console.log("Record has not been saved due to",err);
})

}

addproduct("pew","Jar",899)