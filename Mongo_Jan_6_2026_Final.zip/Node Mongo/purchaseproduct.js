const mongoose=require('mongoose')
const dbConfig=require('./config/db.config.js')
const Product=require('./model/product.model.js')
const SaleProduct = require('./model/saleproduct.model.js');
const PurchaseProduct = require('./model/purchase.model.js')

mongoose.connect(dbConfig.url).then(()=>{
    console.log("database connected")
}).catch((err)=>{
     console.log("database not connected due to",err)
})

// Updating Stock Logic 

      const updateStock = async (productId,quantity = 0,isPurchase = false) => {

        // find the product
        const product  = await Product.find({productID:productId}); // [......]
        var updatedStockQuantity = 0;

        if(isPurchase){
            
            updatedStockQuantity = product[0]?.quantityInStock + quantity;
        }else{

            updatedStockQuantity = product[0]?.quantityInStock - quantity;

        }


                  if(product.length > 0){

                            // DB_OPS x

                    await Product.updateOne(
                        {productID:productId}, // if productId matches (Filters)
                        {$set:{quantityInStock:updatedStockQuantity}}, // Only Changes in Packet
                        {upsert:true} // if not matches found , insert new one (Options)
                    ).then(()=>{
                        console.log("Stock Updated Successfully !");
                    }).catch((err)=>{

                        console.log("error happen due to :",err);
                    });

        }
        
}



purchaseProductSale = async function(id,qty){

// Find Product DB_OPS X

var product  = await Product?.find({productID:id}); // [....] Array of products

        
        if(product.length > 0){

            
            const purchaseproduct1 = new PurchaseProduct({
            
                productName:product[0]?.productName,
                productLine:product[0]?.productLine,
                productScale:product[0]?.productScale,
                productVendor:product[0]?.productVendor,
                productDescription:product[0]?.productDescription,
                quantityInStock:product[0]?.quantityInStock,
                buyPrice:product[0]?.buyPrice,
                MSRP:product[0]?.MSRP,
                image:product[0]?.image,
                productID:product[0]?.productID,
                productQty:qty ?? 0
                
            })

            // Saving Product Sale
            await purchaseproduct1?.save().then(()=>{
                console.log("Product purchase has been Record");

                // Update Stock
                updateStock(id,qty,true);
            }).catch((err)=>{
                console.log("Record has not been saved due to",err);
            })



    }else{
        console.log("This Product does not exisit");
        // Later on please code for new purchasing here ...

    }

}


purchaseProductSale(15,75)