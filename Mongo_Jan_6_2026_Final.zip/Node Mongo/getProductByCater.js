const mongoose=require("mongoose")
const dbConfig = require("./config/db.config")
const Product =require("./model/product.model")


mongoose.connect(dbConfig?.url).then(()=>{

    console.log("database connected successfully!");
}).catch((error)=>{

    console.log("error due to :",error);
});



getProductByCater = async function (){

    // Like aggregate function are sepecial function 
    // in db's where some functions are given for Atomic tasks here some of then  
        await Product.aggregate([
            {
                $group:{
                    _id:"$productLine",
                    totalNoOfProducts:{$sum:1},
                    totalStock:{$sum:"$quantityInStock"},
                    minPrice:{$min:"$buyPrice"},
                    maxPrice:{$max:"$buyPrice"},
                    avgPrice:{$avg:"$buyPrice"}
                }
            },
            {
                $sort:{_id:-1}
            },
            {
                $limit:5
            }
        ])
            .then((data)=>{
                      console.log(data);
                    })
                        .catch((err)=>{
                            console.log("Error occur due to :",err);
                        })

}


getProductByCater();