const mongoose=require("mongoose")
const dbConfig = require("./config/db.config")
const Product =require("./model/product.model")


mongoose.connect(dbConfig?.url).then(()=>{

    console.log("database connected successfully!");
}).catch((error)=>{

    console.log("error due to :",error);
});



getProductByPrice = async function (minPrice,maxPrice,page){

    // Calculation
    // 10 * 1-1 = Skip 0
    // 10 *  2-1 = Skip 10
    // 10 * 3 -1 = skip 20
    // 10 * 4-1  = skip 30 =  {{10 x 3}}

    var pageSize = 10;
    var skipRecords = pageSize*(page-1);

    if(minPrice < maxPrice && maxPrice > minPrice){

        try {
            
            await Product.find(
                {
                    $and:[
                        {buyPrice:{$gte:minPrice}},
                        {buyPrice:{$lte:maxPrice}},
                        {productLine:"Classic Cars"}
                    ]
                }
            )
            .skip(skipRecords)
            .limit(pageSize)
            .sort({productID:1}) // asc
            .then((data)=>{
                      console.log(data);
                    })
                        .catch((err)=>{
                            console.log("Error occur due to :",err);
                        })

        } catch (error) {
            
        }


    }else{
        console.log("Mininum price should be less then maximum price!");
    }
    
    


}


getProductByPrice(30,70,2);