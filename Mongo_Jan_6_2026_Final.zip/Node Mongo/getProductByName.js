const mongoose=require("mongoose")
const dbConfig = require("./config/db.config")
const Product =require("./model/product.model")


mongoose.connect(dbConfig?.url).then(()=>{

    console.log("database connected successfully!");
}).catch((error)=>{

    console.log("error due to :",error);
});



getProductByName = async function (keyword,page){

    // Calculation
    // 10 * 1-1 = Skip 0
    // 10 *  2-1 = Skip 10
    // 10 * 3 -1 = skip 20
    // 10 * 4-1  = skip 30 =  {{10 x 3}}

    var pageSize = 10;
    var skipRecords = pageSize*(page-1);

        await Product.find({
            productName:{$regex:new RegExp(keyword,"i")}
        })
            .skip(skipRecords)
            .limit(pageSize)
            .sort({productID:1}) // asc
            .then((data)=>{
                      console.log(data);
                    })
                        .catch((err)=>{
                            console.log("Error occur due to :",err);
                        })

}


getProductByName("1969",1);