const mongoose=require('mongoose')
const dbConfig=require('./config/db.config.js')
const Product=require('./model/product.model.js')

mongoose.connect(dbConfig.url).then(()=>{
    console.log("database connected")
}).catch((err)=>{
     console.log("database not connected due to",err)
})
updateproduct=async function(name,cat,price,id)
{
const noofrec=await Product.find({productID:id}).countDocuments()   
if (noofrec>0)
{    
const product1={    
productName:name,
productLine:cat,
productScale:"1:10",
productVendor:"Red Start Diecast",
productDescription:"Model features, official Harley Davidson logos and insignias, detachab…",
quantityInStock:5582,
buyPrice:price,
MSRP:"193.66",
image:"data/4.jpg",
}

await Product.updateOne(
{productID:id},
{$set:product1},
{upsert:true}
).then(()=>{
    console.log("Record has been updated")
}).catch((err)=>{
    console.log("Record has not been updated due to",err)
})
}
else
{
    console.log("Record not found for the given id")}

}

updateproduct("abc","xyz",5678,4)