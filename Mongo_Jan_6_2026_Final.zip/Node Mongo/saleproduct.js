const mongoose=require('mongoose')
const dbConfig=require('./config/db.config.js')
const Product=require('./model/product.model.js')
const SaleProduct = require('./model/saleproduct.model.js');

mongoose.connect(dbConfig.url).then(()=>{
    console.log("database connected")
}).catch((err)=>{
     console.log("database not connected due to",err)
})

// Updating Stock Logic 

      const updateStock = async (productId,quantity = 0) => {

        // find the product
        const product  = await Product.find({productID:productId}); // [......]

           const updatedStockQuantity = product[0]?.quantityInStock - quantity;

                  if(product.length > 0){

                            // DB_OPS x

                    await Product.updateOne(
                        {productID:productId}, // if productId matches (Filters)
                        {$set:{quantityInStock:updatedStockQuantity}}, // Only Changes in Packet
                        {upsert:true} // if not matches found , insert new one (Options)
                    ).then(()=>{
                        console.log("Stock Updated Successfully !");
                    }).catch((err)=>{

                        console.log("error happen due to :",err);
                    });

        }
        
}



saveProductSale = async function(id,qty){

// Find Product DB_OPS X

var product  = await Product?.find({productID:id}); // [....] Array of products

   if(+qty > +product[0]?.quantityInStock){

            console.log("Sorry, stock are not enough!");

            return;
        }else{

            // Create New Document with Product Details that you juts findand also add Quantity
            // Quantity
            const saleproduct1 = new SaleProduct({
            
                productName:product[0]?.productName,
                productLine:product[0]?.productLine,
                productScale:product[0]?.productScale,
                productVendor:product[0]?.productVendor,
                productDescription:product[0]?.productDescription,
                quantityInStock:product[0]?.quantityInStock,
                buyPrice:product[0]?.buyPrice,
                MSRP:product[0]?.MSRP,
                image:product[0]?.image,
                productID:product[0]?.productID,
                productQty:qty ?? 0
                
            })

            // Saving Product Sale
            await saleproduct1?.save().then(()=>{
                console.log("Product Sale has been Record");

                // Update Stock
                updateStock(id,qty);
            }).catch((err)=>{
                console.log("Record has not been saved due to",err);
            })
        }



}


saveProductSale(6,4500);