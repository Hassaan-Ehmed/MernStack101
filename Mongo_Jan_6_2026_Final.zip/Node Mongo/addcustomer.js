const mongoose=require('mongoose')
const dbConfig=require('./config/db.config.js')
const Customer=require('./model/customer.model.js')

mongoose.connect(dbConfig.url).then(()=>{
    console.log("database connected")
}).catch((err)=>{
     console.log("database not connected due to",err)
})




addCustomer = async function(name,phone,address){


    // Getting Maximum Number : DB_OPS X
    var customerCount = await Customer.find().countDocuments();
    const maxId = customerCount + 1 ;


    //Customer Packet 
    const customer1=new Customer({    

        customerNumber:maxId,
        customerName:name,
        contactLastName:"Khan",
        contactFirstName:"Hassaan",
        phone: phone,
        addressLine1:address,
        addressLine2:null,
        city:"Karachi",
        state:null,
        postalCode:"440002",
        country:"Pakistan",
        salesRepEmployeeNumber:"8067",
        creditLimit:"118200",
        email:"harry@hotmail.com",
        file:"",
        pwd:"AJHSA00110101&*($&$&",
        type:"M"
})

await customer1.save().then(()=>{ // DB_OPS X
    console.log("Record has been saved with Id : ",maxId);
}).catch((err)=>{
    console.log("Record has not been saved due to",err);
})

}

addCustomer("Hassaan Ahmed Khan","40.67.85552","67, rue des Cinquante Otages2");
