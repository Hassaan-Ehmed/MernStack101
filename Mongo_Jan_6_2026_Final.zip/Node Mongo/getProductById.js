const mongoose  = require("mongoose")
const dbConfig = require("./config/db.config")
const Product = require("./model/product.model")


mongoose.connect(dbConfig.url).then(()=>{

    console.log("database connected successfully!");

}).catch((err)=>{

    console.log("error occur due to : ,",err);
});


const getProductById =  async (id)=>{

    await Product.find({productID:id}).then((data)=>{
        console.log("Data: ",data);

    }).catch((err)=>{
        console.log("Error occur due to : ",err);
    })

}

getProductById(3)