const mongoose=require('mongoose')
const dbConfig=require('./config/db.config.js')
const Product=require('./model/product.model.js')

mongoose.connect(dbConfig.url).then(()=>{
    console.log("database connected")
}).catch((err)=>{
     console.log("database not connected due to",err)
})
deleteproduct=async function(id)
{
const productCount =await Product.find({productID:id}).countDocuments()   

if (productCount > 0)
{    

    await Product.deleteMany(
        
        { productID:id }
    ).
    then(()=>{
    console.log("Product Record has been deleted")
}).catch((err)=>{
    console.log("Record has not been deleted due to",err)
})


}
else
{
    console.log("Record not found for the given id")}

}

deleteproduct(21)