const mongoose=require("mongoose")
const dbConfig = require("./config/db.config")
const Product =require("./model/product.model")


mongoose.connect(dbConfig?.url).then(()=>{

    console.log("database connected successfully!");
}).catch((error)=>{

    console.log("error due to :",error);
});



getProductByPrice = async function (minPrice,maxPrice){

    if(minPrice < maxPrice && maxPrice > minPrice){

        try {
            
            await Product.find(
                {
                    $and:[
                        {buyPrice:{$gte:minPrice}},
                        {buyPrice:{$lte:maxPrice}},
                        {productLine:"Classic Cars"}
                    ]
                }
            ).then((data)=>{
                      console.log(data);
                    })
                        .catch((err)=>{
                            console.log("Error occur due to :",err);
                        })

        } catch (error) {
            
        }


    }else{
        console.log("Mininum price should be less then maximum price!");
    }
    
    


}


getProductByPrice(20,80);