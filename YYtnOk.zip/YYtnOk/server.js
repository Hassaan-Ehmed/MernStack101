const mongoose=require('mongoose')
const dbConfig=require('./config/db.config.js')

mongoose.connect(dbConfig.url).then(()=>{
    console.log("database connected")
}).catch((err)=>{
     console.log("database not connected due to",err)
})