import Product from '../models/product.model.js'

const getAllProducts=async(req,res)=>{
    try {
        
        const pageSize=10;
        const page=req.params.page;
        const skip=pageSize*(page-1);

        await Product.find()
        .skip(skip)
        .limit(pageSize)
        .sort({productID:1})
        .then((data)=>{
               res.json(data);
        }).catch((error)=>{
            res.status(500).json({ message: error.message });
        });
        
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
}


const getProductById = async(req,res)=>{
    try{

        const id = parseInt(req.params.id);
        
        await Product.find({productID:id})
        .then((data)=>{
        
            res.json(data);
        
            }).catch((error)=>{
                res.status(500).json({message:error?.message});
            })


    }catch(error){
        res.status(500).json({message:error?.message});
    }
}


const getProductByName = async(req,res)=>{
    try{

        var name = req?.params?.name;
        
        await Product.find(
            {$or:[   
                // i -> case insensitive
                   {productName:{$regex: new RegExp(name,'i') } },
                   {productLine:{$regex: new RegExp(name,'i') } },
                   {productVendor:{$regex: new RegExp(name,'i') } },
                   {productDescription:{$regex: new RegExp(name,'i') } }
            ]}
         
        )
        .then((data)=>{
        
            res.json(data);
        
            }).catch((error)=>{
                res.status(500).json({message:error?.message});
            })


    }catch(error){
        res.status(500).json({message:error?.message});
    }
}
const addProduct = async(req,res)=>{
    try{

        var name = req?.params?.name;
        var category = req?.params?.category;
        var price = req?.params?.price;

        const countProducts = await Product?.find({})?.countDocuments();
        const maxId  =  +countProducts + 1


        const newProduct = new Product({

        productName:name,
        productLine:category,
        productScale:'3:12',
        productVendor:'Zahoor Uncle',
        productDescription:'3:12 scale replica of actual games UH-60L BLACK HAWK Helicopter. 100% hand-assembled. Features rotating rotor blades, propeller blades and rubber wheels.',
        quantityInStock:4500,
        buyPrice:price,
        MSRP:178.62,
        image:'',
        productID:maxId
    
    });

        await newProduct.save().then(
            ()=>{
        
            res.status(201).json({message:`Product Addedd !, with id: ${maxId}`});
        
            }).catch((error)=>{
                res.status(500).json({message:error?.message});
            })


    }catch(error){
        res.status(500).json({message:error?.message});
    }
}


const getProductByCat = async function (req,res){

    var name  = req.params.cat;
    const pageSize = 10;
    const page = req.params.page;
    const skipRecords = pageSize*(page-1);

        try {
            
            await Product.find({
                productLine :{$regex: new RegExp(name,'i')}
            })
            .skip(skipRecords)
            .limit(pageSize)
            .sort({productID:1}) // asc
            .then((data)=>{
                      res.json(data);
                    })
                        .catch((err)=>{
                            res.status(500).json({message:err.message});
                        })

        } catch (error) {
            
        }

    


}

const updateProduct = async(req,res)=>{
    try{

        var id = req?.params?.id;
        var name = req?.params?.name;
        var category = req?.params?.category;
        var price = req?.params?.price;

        
      const product = {
        productName:name,
        productLine:category,
        productScale:'3:12',
        productVendor:'',
        productDescription:'3:12 scale replica of actual games UH-60L BLACK HAWK Helicopter. 100% hand-assembled. Features rotating rotor blades, propeller blades and rubber wheels.',
        quantityInStock:4500,
        buyPrice:price,
        MSRP:178.62,
        image:'',
        }

        await Product.updateMany(
            {productID:id},  // finding query
            {$set:product}, // actual updation
            {upsert:true}  // insert if no matches   
        ).then(
            ()=>{
        
            res.status(200).json({message:"Product Updated !"});
        
            }).catch((error)=>{
                res.status(500).json({message:error?.message});
            })


    }catch(error){
        res.status(500).json({message:error?.message});
    }
}

export {
    getAllProducts,
    getProductById,
    getProductByName,
    addProduct,
    updateProduct,
    getProductByCat
};