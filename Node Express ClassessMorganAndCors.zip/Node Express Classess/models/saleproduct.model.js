import mongoose from "mongoose"

const saleProductSchema=mongoose.Schema(
    {
    productName:String,
    productLine:String,
    productScale:String,
    productVendor:String,
    productDescription:String,
    quantityInStock:Number,
    buyPrice:Number,
    MSRP:String,
    image:String,
    productID:Number,
    productQty:Number
    },
    {
        timestamps:true
    }
)

export default mongoose.model('saleproduct',saleProductSchema)