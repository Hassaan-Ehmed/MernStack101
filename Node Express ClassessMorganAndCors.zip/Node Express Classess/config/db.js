import mongoose from "mongoose";

const connectDB = async ()=>{
    try{

        await mongoose.connect('mongodb://localhost:27017/AptechDB')
        .then(()=>{
            console.log("MongoDb Database connected Successfully !");
        }).catch((error)=>{
            console.log("MongoDb Connection Error: ",error);
        })

    }
    catch(error){
        console.error("Error while trying to connect with database:",error);
        process.exit(1);
    }
}

export default connectDB;