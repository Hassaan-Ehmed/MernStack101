import express from 'express';
import { getAllProducts ,
     getProductById ,
      getProductByName,
      addProduct,
      updateProduct,
      getProductByCat
    } from '../controller/ProductController.js';       
import {getAllcustomers} from '../controller/CustomerController.js';

const router = express.Router();

router.get('/products/:page', getAllProducts);
router.get('/customers', getAllcustomers);
router.get('/getProductById/:id',getProductById);
router.get('/getProductByName/:name',getProductByName);
router.get('/addProduct/:name/:category/:price',addProduct);
router.get('/updateProduct/:id/:name/:category/:price',updateProduct)
router.get('/getProductByCat/:cat/:page',getProductByCat)

export default router;