import express from 'express';
import connectDB from './config/db.js'
import router from './routes/route.js';
import cors from 'cors'
import morgan from 'morgan'
import fs from 'fs'
import path from 'path';




const coreOptions = {
    origin:'http://localhost:3000',
    Credential:true,
    optionsSuccessStatus:200
}
const app = express(); // Making Object using Express (Instance) - Middleware
const port = process.env.PORT || 5000; // Getting seceret port 😜 

connectDB(); // Database Connection
app.use(express.json()); // Telling our app that use JSON format for Data Exchange
//   instead of XML (old)

app.use(cors(coreOptions)); // Applying cors on Backend to
//  allow interation of frontend port 3000 


// Setup morgan for logging
const logDirectory = 'C:/LogData';

    if(!fs.existsSync(logDirectory)){
        
            fs.mkdirSync(logDirectory);
    }
    
const logFile = path.join(logDirectory,'log.txt');
const accessLogStream = fs.createWriteStream(logFile,{flags:'a'});

app.use(morgan('dev'));
app.use(morgan('combined',{stream:accessLogStream}));


app.use("/",router);
// `GET` request handle for /root route of our webpage

app.get('/',(req,res)=>{ // Whenever

    res.send('Hello World !');
});

app.listen(port,()=>{
    console.log('Server is running on http://localhost:' + port);
})


