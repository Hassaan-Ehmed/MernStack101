import Customer from '../models/customer.model.js';

const getAllcustomers=async(req,res)=>{
    try {
        const customers=await Customer.find();
        res.json(customers);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
}

export {getAllcustomers};