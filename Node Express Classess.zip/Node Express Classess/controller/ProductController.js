import Product from '../models/product.model.js'

const getAllProducts=async(req,res)=>{
    try {
        
        const pageSize=10;
        const page=req.params.page;
        const skip=pageSize*(page-1);

        await Product.find()
        .skip(skip)
        .limit(pageSize)
        .sort({productID:1})
        .then((data)=>{
               res.json(data);
        }).catch((error)=>{
            res.status(500).json({ message: error.message });
        });
        
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
}


const getProductById = async(req,res)=>{
    try{

        const id = parseInt(req.params.id);
        
        await Product.find({productID:id})
        .then((data)=>{
        
            res.json(data);
        
            }).catch((error)=>{
                res.status(500).json({message:error?.message});
            })


    }catch(error){
        res.status(500).json({message:error?.message});
    }
}


const getProductByName = async(req,res)=>{
    try{

        var name = req?.params?.name;
        
        await Product.find(
            {$or:[   
                // i -> case insensitive
                   {productName:{$regex: new RegExp(name,'i') } },
                   {productLine:{$regex: new RegExp(name,'i') } },
                   {productVendor:{$regex: new RegExp(name,'i') } },
                   {productDescription:{$regex: new RegExp(name,'i') } }
            ]}
         
        )
        .then((data)=>{
        
            res.json(data);
        
            }).catch((error)=>{
                res.status(500).json({message:error?.message});
            })


    }catch(error){
        res.status(500).json({message:error?.message});
    }
}
const addProduct = async(req,res)=>{
    try{

        var name = req?.params?.name;
        var category = req?.params?.category;
        var price = req?.params?.price;

        

        const newProduct = new Product({

        productName:name,
        productLine:category,
        productScale:'3:12',
        productVendor:'Chacha Aslam',
        productDescription:'3:12 scale replica of actual games UH-60L BLACK HAWK Helicopter. 100% hand-assembled. Features rotating rotor blades, propeller blades and rubber wheels.',
        quantityInStock:4500,
        buyPrice:price,
        MSRP:178.62,
        image:'',
        productID:10001
    
    });

        await newProduct.save().then(
            ()=>{
        
            res.status(201).json({message:"Product Addedd !"});
        
            }).catch((error)=>{
                res.status(500).json({message:error?.message});
            })


    }catch(error){
        res.status(500).json({message:error?.message});
    }
}

export {getAllProducts,getProductById,getProductByName,addProduct};