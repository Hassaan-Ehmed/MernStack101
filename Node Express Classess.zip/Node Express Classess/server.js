import express from 'express';
import connectDB from './config/db.js'


const app = express(); // Making Object using Express (Instance)
const port = process.env.PORT || 5000; // Getting seceret port 😜 

connectDB(); // Database Connection

app.use(express.json()); // Telling our app that use JSON format for Data Exchange
                        //   instead of XML (old)
    
// `GET` request handle for /root route of our webpage

app.get('/',(req,res)=>{ // Whenever

    res.send('Hello World !');
});

app.listen(port,()=>{
    console.log('Server is running on http://localhost:' + port);
})


