import express from 'express';
import { getAllProducts , getProductById , getProductByName,addProduct} from '../controller/ProductController.js';       
import {getAllcustomers} from '../controller/CustomerController.js';

const router = express.Router();

router.get('/products/:page', getAllProducts);
router.get('/customers', getAllcustomers);
router.get('/getProductById/:id',getProductById);
router.get('/getProductByName/:name',getProductByName);
router.get('/addProduct/:name/:category/:price',addProduct);

export default router;