const mongoose=require('mongoose')

const purchaseProductSchema = mongoose.Schema({

    productName:String,
    productLine:String,
    productScale:String,
    productVendor:String,
    productDescription:String,
    quantityInStock:Number,
    buyPrice:Number,
    MSRP:String,
    image:String,
    productID:Number,
    productQty:Number},
    {
        timestamps:true
    }
)

module.exports = mongoose.model('purchaseproduct',purchaseProductSchema)