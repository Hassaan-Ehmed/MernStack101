const mongoose = require("mongoose");
const dbConfig = require("./config/db.config")
const Product = require("./model/product.model")

mongoose.connect(dbConfig.url).then(()=>{

    console.log("database connected successsfully !");

}).catch((error)=>{
    console.log("database connection are not established due to: ",error);

});

getAllProduct = async function(){

    await Product.find().then((data)=>{

        console.log("data",data);

    }).catch((err)=>{
    console.log("products not found due to: ",err);

    })
} 


getAllProduct();
