const mongoose=require('mongoose')
const dbConfig=require('./config/db.config.js')
const Customer=require('./model/customer.model.js')

mongoose.connect(dbConfig.url).then(()=>{
    console.log("database connected")
}).catch((err)=>{
     console.log("database not connected due to",err)
})


deletecustomer=async function(userId)
{
const customersCount = await Customer.find({customerNumber:userId}).countDocuments()   

if (customersCount > 0)
{    

    await Customer.deleteMany( // delete many records if exsist , otherwise delete one
        { customerNumber:userId }
    ).
    then(()=>{
    console.log("Customer Record has been deleted");
}).catch((err)=>{
    console.log("Customer Record has not been deleted due to",err);
})


}
else
{
    console.log("Record not found for the given user id")}

}

deletecustomer(171)